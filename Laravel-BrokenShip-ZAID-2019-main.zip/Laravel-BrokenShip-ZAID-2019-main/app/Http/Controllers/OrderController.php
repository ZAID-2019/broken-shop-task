<?php

namespace App\Http\Controllers;

use App\Jobs\ChargePaymentJob;
use App\Models\Order;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class OrderController extends Controller
{
    public function addToCart(Request $request, $id)
    {

        $cart = $request->session()->get('cart', []);
        $cart[] = Product::find($id);
        $request->session()->put('cart', $cart);

        return redirect('/');
    }

    public function checkout(Request $request)
    {

        $cart = $request->session()->get('cart', []);

        $total = 0;
        foreach ($cart as $p) {
            $total += (float) ($p->price ?? 0);
        }

        DB::beginTransaction();

        $order = new Order();
        $order->user_id = $request->input('user_id');
        $order->items = json_encode($cart);
        $order->total = (string) $total;
        $order->status = 'new';
        $order->payment_status = 'pending';
        $order->save();


        ChargePaymentJob::dispatch($order)->onQueue('default');

        DB::commit();

        $request->session()->forget('cart');

        return response()->json(['ok' => true, 'order_id' => $order->id]);
    }
}
