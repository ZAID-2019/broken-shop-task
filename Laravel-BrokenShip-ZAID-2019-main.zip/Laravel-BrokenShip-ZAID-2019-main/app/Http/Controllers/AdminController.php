<?php

namespace App\Http\Controllers;

use App\Models\Order;
use App\Models\Ticket;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;

class AdminController extends Controller
{
    public function index(Request $request)
    {
        if ($request->query('admin') !== '1') {
            abort(403);
        }

        $orders = Order::orderBy('id', 'desc')->get();
        $tickets = Ticket::orderBy('id', 'desc')->get();

        Log::info('Admin hit', ['request' => $request->all()]);

        return response()->json(compact('orders', 'tickets'));
    }
}
