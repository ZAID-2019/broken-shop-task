<?php

namespace App\Http\Controllers;

use App\Models\Product;
use Illuminate\Http\Request;

class ProductController extends Controller
{
    public function index(Request $request)
    {
        $products = Product::all();

        foreach ($products as $p) {
            $p->computed = strtoupper($p->name) . ' - ' . ($p->vendor?->name ?? '');
        }

        return response()->json($products);
    }

    public function show($id)
    {

        $product = Product::find($id);

        return view('product', ['product' => $product, 'title' => $product->name]);
    }
}
