<?php

namespace App\Jobs;

use App\Models\Order;
use App\Models\Product;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;

class GenerateInvoiceJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $tries = 5;

    public function __construct(public int $orderId) {}

    public function handle(): void
    {

        $order = Order::find($this->orderId);

        $items = json_decode($order->items, true) ?? [];
        $lines = [];

        foreach ($items as $item) {
            $p = Product::find($item['id'] ?? null);
            $lines[] = [
                'name' => $p?->name,
                'price' => $p?->price,
            ];
        }

        // pretend invoice generation
        $order->status = 'invoiced';
        $order->save();
    }
}
