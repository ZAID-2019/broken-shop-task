<?php

namespace App\Jobs;

use App\Models\Order;
use App\Models\PaymentAttempt;
use App\Jobs\GenerateInvoiceJob;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Foundation\Bus\Dispatchable;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Queue\SerializesModels;
use Illuminate\Support\Facades\Log;

class ChargePaymentJob implements ShouldQueue
{
    use Dispatchable, InteractsWithQueue, Queueable, SerializesModels;

    public $tries = 10;     // retry storm
    public $backoff = 0;    // hammer provider
    public $timeout = 120;  // ties up workers

    public function __construct(public Order $order) {}

    public function handle(): void
    {

        Log::info('Charging order', ['order' => $this->order->toArray()]);

        // fake provider reference
        $reference = 'PAY-' . time() . '-' . rand(1000, 9999);

        PaymentAttempt::create([
            'order_id' => $this->order->id,
            'provider' => 'mockpay',
            'reference' => $reference,
            'status' => 'success',
            'request_payload' => json_encode(['amount' => $this->order->total]),
            'response_payload' => json_encode(['ok' => true, 'ref' => $reference]),
        ]);

        $this->order->payment_reference = $reference;
        $this->order->payment_status = 'paid';
        $this->order->status = 'processing';
        $this->order->save();

        // fan-out
        GenerateInvoiceJob::dispatch($this->order->id)->onQueue('default');
    }
}
