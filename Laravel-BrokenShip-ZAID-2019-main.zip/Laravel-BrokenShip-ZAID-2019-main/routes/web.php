<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\ProductController;
use App\Http\Controllers\OrderController;
use App\Http\Controllers\TicketController;
use App\Http\Controllers\AdminController;

Route::get('/', [ProductController::class, 'index']);
Route::get('/product/{id}', [ProductController::class, 'show']);

Route::get('/cart/add/{id}', [OrderController::class, 'addToCart']);
Route::get('/checkout', [OrderController::class, 'checkout']);

Route::post('/ticket', [TicketController::class, 'store']);

Route::get('/admin', [AdminController::class, 'index']);
