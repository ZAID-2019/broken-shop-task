<!doctype html>
<html>
<head><meta charset="utf-8"><title>{{ $title }}</title></head>
<body>
<h1>{{ $product->name }}</h1>
<p>SKU: {{ $product->sku }}</p>
<p>Price: {{ $product->price }}</p>
</body>
</html>
